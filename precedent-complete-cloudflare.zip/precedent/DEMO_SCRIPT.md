# Demo Script — for your live walkthrough

Goal: show, live, that Precedent gets measurably better after you correct
it, not just tell people it does. Total time: ~8-10 minutes.

## Before you start

- [ ] `./scripts/build.sh` then `./scripts/run.sh` — confirm `localhost:8000`
      loads the dashboard with no console errors
- [ ] Decide MOCK_MODE (true = guaranteed to work, no rate limits; false =
      real Groq calls, more impressive but rate-limited at 30 req/min)
- [ ] Run `python scripts/run_demo.py` once beforehand as a rehearsal —
      confirms the trend actually declines before you're in front of anyone
- [ ] **Reset the database before the live run** (`rm backend/precedent.db
      backend/chroma_data -rf`) so the panel sees the correction rate
      actually drop from a fresh start, not from your rehearsal data

## The walkthrough

**1. Show a clean review (30 sec)**
Paste a PR into the input box:
> "Refactored the parser to catch a specific ValueError and TypeError instead of a broad catch-all."

Point out: it retrieved a real guideline, cited which one, gave a verdict.
This is Phase 2 — static RAG, no correction memory involved yet.

**2. Show the agent getting something wrong (1 min)**
Paste:
> "This PR wraps the entire request handler in a bare except: pass to stop 500s from showing in logs."

The agent will flag *something*, but not necessarily with the emphasis a
senior reviewer would give a silent-failure bug. Narrate: "This is a common
failure mode for LLM reviewers — it's not *wrong*, but it's not treating
this as the hard blocker it should be."

**3. Correct it, live (1 min)**
Click **Correct**. Type:
> "REQUEST_CHANGES: never swallow exceptions silently — catch specific exception types and log them."

Reason: "Bare except clauses hide real failures — this is a hard rule."

Submit. Point at the **Correction memory** panel on the right — the
correction is now stored.

**4. Prove it transfers to a DIFFERENT but similar PR (2 min) — this is the core claim**
Paste a paraphrased, not identical, version:
> "New retry decorator wraps the whole loop in a bare except: pass to avoid crashing the worker."

Point at the response: it should now cite the past correction (visible as
the amber "Following past correction" line), not repeat the original miss.
**This is the whole thesis of the project** — say that explicitly.

**5. Run the full batch and show the chart (2 min)**
In a second terminal: `python scripts/run_demo.py`

This feeds all 30 sample PRs through, auto-correcting the first occurrence
of each of 11 distinct issue patterns and leaving repeats/clean PRs alone.
Switch back to the dashboard — the **correction-rate chart** on the right
should show a declining line across the three batches.

**6. Cite the number (30 sec)**
Say the actual numbers from your `/stats` — don't say "it got better," say
"batch 1 needed correction on 70% of reviews; by batch 3 that's 0%." This
is the metric your report should quote.

## If something goes wrong live

- **Groq rate-limited / no internet**: you're already covered — MOCK_MODE
  still runs the full retrieval pipeline, just with a canned generation
  step. Say so plainly if asked: "this is running in mock mode for
  reliability; the retrieval and correction-memory logic underneath is the
  same either way."
- **Chart is empty**: you need 10+ reviews logged before batch 1 completes.
  Run `scripts/run_demo.py` if you haven't yet.
- **A correction doesn't transfer to a paraphrase**: this is a real
  possibility if `CORRECTION_SIMILARITY_THRESHOLD` is set too tight for
  your embedding model — see `scripts/calibrate_threshold.py`. Don't
  panic; explain the mechanism (embedding distance vs. a tunable
  threshold) rather than pretending it should be perfect. That's actually
  a *better* viva answer than a demo where everything works magically.
