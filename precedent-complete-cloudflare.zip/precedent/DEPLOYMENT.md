# Deployment — Public URL via Cloudflare Tunnel

Single-origin setup: FastAPI serves both the API and the built React app
on one port, so one tunnel covers everything — no CORS juggling, no two
URLs to share.

## 1. Build and run locally first

```bash
./scripts/build.sh   # installs deps, builds frontend into frontend/dist
./scripts/run.sh      # starts the server on http://localhost:8000
```

Confirm `http://localhost:8000` loads the dashboard before moving on —
tunneling a broken local server just gives you a broken public one.

## 2. Install cloudflared (one-time)

**Linux (Debian/Ubuntu, x86_64):**
```bash
curl -L --output cloudflared.deb https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared.deb
```

**macOS (Homebrew):**
```bash
brew install cloudflared
```

**Windows (PowerShell, via winget):**
```powershell
winget install --id Cloudflare.cloudflared
```

Verify it installed: `cloudflared --version`

## 3. Start the tunnel

With `./scripts/run.sh` still running in one terminal, in a second terminal:

```bash
./scripts/deploy_tunnel.sh
```

or directly:

```bash
cloudflared tunnel --url http://localhost:8000
```

Cloudflared prints a URL like `https://random-words-1234.trycloudflare.com`
within a few seconds. That's your public link.

## 4. Verify it's actually public before sharing it

Don't just trust the terminal output — confirm from outside your machine:

- Open the URL on your phone with **WiFi off** (cellular data only), or
- Send it to a friend on a different network and ask them to load it, or
- Use a third-party "is my site up" checker (e.g. downforeveryoneorjustme.com)
  pointed at your tunnel URL.

If it only loads on your own network, the tunnel isn't actually running —
check the `cloudflared` terminal for errors before telling anyone it's ready.

## Important caveats (read before your demo)

- **The CPU-only PyTorch install (`build.sh`) couldn't be fully verified
  in the sandbox this was built in** — `download.pytorch.org` was blocked
  there, and even plain PyPI torch downloads kept getting interrupted on
  that sandbox's bandwidth. The fix itself (`pip install torch --index-url
  https://download.pytorch.org/whl/cpu`) is the officially documented
  approach and should work fine on a normal internet connection — this is
  just flagging that I couldn't watch it succeed end-to-end myself. If it
  fails on your machine for any reason, delete the PyTorch install step
  from `scripts/build.sh` and just let `pip install -r requirements.txt`
  pull the default build instead — it'll work, just download more (2GB+)
  than necessary.
- **This is a quick tunnel** (no Cloudflare account) — the fastest, zero-setup
  option, but the URL **changes every time you restart `cloudflared`**. If you
  need the *same* link across multiple faculty check-ins over several days,
  you'll need a free Cloudflare account + a named tunnel instead (more setup,
  ask me if you want this).
- **The tunnel only stays up while your machine is on and `cloudflared` is
  running.** Closing your laptop kills the public URL. Start both
  `./scripts/run.sh` and `./scripts/deploy_tunnel.sh` fresh right before any
  live demo.
- **MOCK_MODE** is on by default (see `backend/.env`). For a live demo where
  you want real Groq-generated reviews, set `MOCK_MODE=false` and add your
  `GROQ_API_KEY` — but keep `MOCK_MODE=true` as your fallback if Groq's free
  tier (30 req/min) gets rate-limited mid-demo.
