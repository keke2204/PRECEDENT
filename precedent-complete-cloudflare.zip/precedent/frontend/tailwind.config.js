/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        base: {
          bg: "#0B0E14",
          panel: "#12151D",
          panelAlt: "#171B26",
          border: "#232838",
        },
        ink: {
          primary: "#E6E8EF",
          secondary: "#9AA1B5",
          muted: "#5B6178",
        },
        agent: {
          DEFAULT: "#5EEAD4",
          dim: "#2E5F58",
        },
        human: {
          DEFAULT: "#F59E0B",
          dim: "#5E4008",
        },
        danger: "#F87171",
      },
      fontFamily: {
        sans: ["Sora", "system-ui", "sans-serif"],
        mono: ["IBM Plex Mono", "ui-monospace", "monospace"],
      },
      spacing: {
        4.5: "1.125rem",
      },
      borderRadius: {
        card: "10px",
      },
    },
  },
  plugins: [],
};
