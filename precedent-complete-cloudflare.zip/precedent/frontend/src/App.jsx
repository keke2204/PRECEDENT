import { useEffect, useState, useCallback } from "react";
import { History } from "lucide-react";
import Header from "./components/Header.jsx";
import ReviewInput from "./components/ReviewInput.jsx";
import ReviewCard from "./components/ReviewCard.jsx";
import CorrectionRateChart from "./components/CorrectionRateChart.jsx";
import { EmptyState, LoadingState, ErrorState } from "./components/States.jsx";
import { api } from "./api.js";

export default function App() {
  const [health, setHealth] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [stats, setStats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const loadAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [h, history, s] = await Promise.all([
        api.health(),
        api.getHistory(),
        api.getStats(),
      ]);
      setHealth(h);
      setReviews([...history].reverse()); // newest first in the feed
      setStats(s);
    } catch (err) {
      setError(err.message || "Could not reach the backend. Is it running?");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const handleSubmitReview = async (input_text) => {
    setSubmitting(true);
    try {
      const result = await api.submitReview(input_text);
      setReviews((prev) => [{ ...result, id: result.review_id, corrected_flag: false }, ...prev]);
      const s = await api.getStats();
      setStats(s);
    } catch (err) {
      setError(err.message || "Review submission failed.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleCorrect = async (reviewId, correctionText, reason) => {
    await api.submitCorrection(reviewId, correctionText, reason);
    setReviews((prev) =>
      prev.map((r) =>
        (r.review_id ?? r.id) === reviewId
          ? { ...r, human_correction: correctionText, corrected_flag: true }
          : r
      )
    );
    const s = await api.getStats();
    setStats(s);
  };

  const correctedReviews = reviews.filter((r) => r.corrected_flag);

  return (
    <div className="min-h-screen bg-base-bg">
      <Header health={health} />

      <main className="max-w-6xl mx-auto px-6 py-6 grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-5">
        {/* Left: input + review feed */}
        <section className="space-y-4">
          <ReviewInput onSubmit={handleSubmitReview} submitting={submitting} />

          {loading && <LoadingState label="Loading review history..." />}
          {!loading && error && <ErrorState message={error} onRetry={loadAll} />}
          {!loading && !error && reviews.length === 0 && (
            <EmptyState label="No reviews yet. Paste a PR description above to get started." />
          )}
          {!loading &&
            !error &&
            reviews.map((r) => (
              <ReviewCard key={r.review_id ?? r.id} review={r} onCorrect={handleCorrect} />
            ))}
        </section>

        {/* Right: correction-rate trend + correction memory panel */}
        <aside className="space-y-4">
          <CorrectionRateChart stats={stats} />

          <div className="panel p-4">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-ink-secondary mb-3">
              <History size={13} />
              Correction memory
            </div>
            {correctedReviews.length === 0 ? (
              <p className="text-[11px] text-ink-muted">
                No corrections logged yet. Correcting a review here teaches
                future similar reviews.
              </p>
            ) : (
              <ul className="space-y-2.5">
                {correctedReviews.slice(0, 8).map((r) => (
                  <li key={r.review_id ?? r.id} className="text-[11px] leading-relaxed">
                    <p className="text-ink-muted font-mono truncate">{r.input_text}</p>
                    <p className="text-human font-mono">→ {r.human_correction}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </aside>
      </main>
    </div>
  );
}
