import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { TrendingDown } from "lucide-react";

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div className="panel px-3 py-2 text-xs font-mono">
      <p className="text-ink-primary font-semibold">Batch {label}</p>
      <p className="text-ink-secondary">{d.corrected}/{d.total} corrected</p>
      <p className="text-human">{d.correction_rate}% correction rate</p>
    </div>
  );
}

export default function CorrectionRateChart({ stats }) {
  if (!stats || stats.length === 0) {
    return (
      <div className="panel p-4">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-ink-secondary mb-1">
          <TrendingDown size={13} />
          Correction rate over time
        </div>
        <p className="text-[11px] text-ink-muted">
          Submit 10+ reviews to see the trend across batches.
        </p>
      </div>
    );
  }

  const data = stats.map((s) => ({ ...s, batch: `${s.batch_number}` }));
  const first = stats[0].correction_rate;
  const last = stats[stats.length - 1].correction_rate;
  const improved = stats.length > 1 && last < first;

  return (
    <div className="panel p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-ink-secondary">
          <TrendingDown size={13} />
          Correction rate over time
        </div>
        {stats.length > 1 && (
          <span className={`text-[11px] font-mono ${improved ? "text-agent" : "text-ink-muted"}`}>
            {first}% → {last}%
          </span>
        )}
      </div>
      <ResponsiveContainer width="100%" height={140}>
        <LineChart data={data} margin={{ top: 5, right: 8, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#232838" vertical={false} />
          <XAxis
            dataKey="batch"
            tick={{ fill: "#5B6178", fontSize: 10, fontFamily: "IBM Plex Mono" }}
            axisLine={{ stroke: "#232838" }}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: "#5B6178", fontSize: 10, fontFamily: "IBM Plex Mono" }}
            axisLine={false}
            tickLine={false}
            domain={[0, 100]}
          />
          <Tooltip content={<CustomTooltip />} />
          <Line
            type="monotone"
            dataKey="correction_rate"
            stroke="#F59E0B"
            strokeWidth={2}
            dot={{ fill: "#F59E0B", r: 3 }}
            activeDot={{ r: 5 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
