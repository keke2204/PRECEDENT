const VERDICT_STYLES = {
  approve: "bg-agent/10 text-agent border-agent/30",
  request_changes: "bg-danger/10 text-danger border-danger/30",
  comment: "bg-ink-secondary/10 text-ink-secondary border-ink-secondary/30",
};

const VERDICT_LABELS = {
  approve: "Approve",
  request_changes: "Request changes",
  comment: "Comment",
};

export default function VerdictBadge({ verdict }) {
  const key = (verdict || "comment").toLowerCase();
  const style = VERDICT_STYLES[key] || VERDICT_STYLES.comment;
  const label = VERDICT_LABELS[key] || verdict;

  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-md border text-xs font-medium font-mono uppercase tracking-wide ${style}`}
    >
      {label}
    </span>
  );
}
