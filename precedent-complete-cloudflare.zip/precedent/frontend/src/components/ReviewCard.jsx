import { useState } from "react";
import { Check, Pencil, BookOpen, History, X, Send } from "lucide-react";
import VerdictBadge from "./VerdictBadge.jsx";

function parseVerdict(agentOutput) {
  const match = agentOutput?.match(/^\[(\w+)\]\s*(.*)$/s);
  if (!match) return { verdict: "comment", reasoning: agentOutput || "" };
  return { verdict: match[1].toLowerCase(), reasoning: match[2] };
}

export default function ReviewCard({ review, onCorrect }) {
  const [mode, setMode] = useState(review.corrected_flag ? "corrected" : "pending");
  const [correctionText, setCorrectionText] = useState("");
  const [reason, setReason] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const { verdict, reasoning } = parseVerdict(review.agent_output);

  const handleAccept = () => setMode("accepted");

  const handleSubmitCorrection = async (e) => {
    e.preventDefault();
    if (!correctionText.trim()) return;
    setSubmitting(true);
    try {
      await onCorrect(review.review_id ?? review.id, correctionText.trim(), reason.trim());
      setMode("corrected");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="panel p-4">
      <div className="flex items-start justify-between gap-3 mb-2.5">
        <p className="text-sm font-mono text-ink-primary leading-relaxed flex-1">
          {review.input_text}
        </p>
        <VerdictBadge verdict={verdict} />
      </div>

      <p className="text-sm text-ink-secondary leading-relaxed mb-3">{reasoning}</p>

      {(review.cited_guideline || review.cited_correction) && (
        <div className="flex flex-col gap-1.5 mb-3">
          {review.cited_guideline && (
            <div className="flex items-start gap-1.5 text-[11px] text-ink-muted font-mono">
              <BookOpen size={12} className="mt-0.5 shrink-0 text-ink-muted" />
              <span>{review.cited_guideline}</span>
            </div>
          )}
          {review.cited_correction && (
            <div className="flex items-start gap-1.5 text-[11px] text-human font-mono">
              <History size={12} className="mt-0.5 shrink-0" />
              <span>Following past correction: {review.cited_correction}</span>
            </div>
          )}
        </div>
      )}

      {mode === "pending" && (
        <div className="flex items-center gap-2 pt-2 border-t border-base-border">
          <button
            onClick={handleAccept}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-agent/10 text-agent text-xs font-medium hover:bg-agent/20 transition-colors"
          >
            <Check size={13} />
            Accept
          </button>
          <button
            onClick={() => setMode("correcting")}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-human/10 text-human text-xs font-medium hover:bg-human/20 transition-colors"
          >
            <Pencil size={13} />
            Correct
          </button>
        </div>
      )}

      {mode === "correcting" && (
        <form onSubmit={handleSubmitCorrection} className="pt-3 border-t border-base-border space-y-2">
          <textarea
            value={correctionText}
            onChange={(e) => setCorrectionText(e.target.value)}
            placeholder="What should the verdict/reasoning have been?"
            rows={2}
            className="w-full bg-base-panelAlt border border-base-border rounded-md px-2.5 py-2 text-xs font-mono text-ink-primary placeholder:text-ink-muted focus:outline-none focus:border-human/50"
            autoFocus
          />
          <input
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Why? (optional, but improves future retrieval)"
            className="w-full bg-base-panelAlt border border-base-border rounded-md px-2.5 py-1.5 text-xs text-ink-secondary placeholder:text-ink-muted focus:outline-none focus:border-human/50"
          />
          <div className="flex items-center gap-2">
            <button
              type="submit"
              disabled={!correctionText.trim() || submitting}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-human text-base-bg text-xs font-semibold disabled:opacity-40 hover:bg-human/90 transition-colors"
            >
              <Send size={12} />
              {submitting ? "Saving..." : "Save correction"}
            </button>
            <button
              type="button"
              onClick={() => setMode("pending")}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-ink-muted text-xs hover:text-ink-secondary transition-colors"
            >
              <X size={12} />
              Cancel
            </button>
          </div>
        </form>
      )}

      {mode === "accepted" && (
        <div className="flex items-center gap-1.5 pt-2 border-t border-base-border text-xs text-agent font-medium">
          <Check size={13} />
          Accepted
        </div>
      )}

      {mode === "corrected" && (
        <div className="pt-2 border-t border-base-border">
          <div className="flex items-center gap-1.5 text-xs text-human font-medium mb-1">
            <Pencil size={13} />
            Corrected
          </div>
          <p className="text-xs text-ink-secondary font-mono">
            {review.human_correction || correctionText}
          </p>
        </div>
      )}
    </div>
  );
}
