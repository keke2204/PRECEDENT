import { GitPullRequest, Zap } from "lucide-react";

export default function Header({ health }) {
  return (
    <header className="flex items-center justify-between px-6 py-4 border-b border-base-border bg-base-bg">
      <div className="flex items-center gap-2.5">
        <div className="w-7 h-7 rounded-md bg-agent/15 flex items-center justify-center">
          <GitPullRequest size={15} className="text-agent" strokeWidth={2.25} />
        </div>
        <div>
          <h1 className="text-sm font-semibold leading-none">Precedent</h1>
          <p className="text-[11px] text-ink-muted leading-none mt-1 font-mono">
            {health?.domain?.replace("_", " ") || "code review"}
          </p>
        </div>
      </div>

      {health && (
        <div className="flex items-center gap-2">
          {health.mock_mode && (
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-human/10 border border-human/30 text-human text-[11px] font-mono">
              <Zap size={11} />
              MOCK MODE
            </span>
          )}
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-agent/10 border border-agent/30 text-agent text-[11px] font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-agent" />
            connected
          </span>
        </div>
      )}
    </header>
  );
}
