import { useState } from "react";
import { ArrowUp, Loader2 } from "lucide-react";

export default function ReviewInput({ onSubmit, submitting }) {
  const [value, setValue] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!value.trim() || submitting) return;
    onSubmit(value.trim());
    setValue("");
  };

  return (
    <form onSubmit={handleSubmit} className="panel p-3">
      <textarea
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Paste a PR description or diff summary to review..."
        rows={3}
        className="w-full bg-transparent text-sm font-mono text-ink-primary placeholder:text-ink-muted resize-none focus:outline-none"
        onKeyDown={(e) => {
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleSubmit(e);
        }}
      />
      <div className="flex items-center justify-between mt-2 pt-2 border-t border-base-border">
        <span className="text-[11px] text-ink-muted font-mono">⌘/Ctrl + Enter to submit</span>
        <button
          type="submit"
          disabled={!value.trim() || submitting}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-agent text-base-bg text-xs font-semibold disabled:opacity-40 disabled:cursor-not-allowed hover:bg-agent/90 transition-colors"
        >
          {submitting ? (
            <Loader2 size={13} className="animate-spin" />
          ) : (
            <ArrowUp size={13} />
          )}
          {submitting ? "Reviewing..." : "Review"}
        </button>
      </div>
    </form>
  );
}
