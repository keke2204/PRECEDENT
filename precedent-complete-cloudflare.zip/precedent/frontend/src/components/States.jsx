import { Inbox, Loader2, AlertTriangle } from "lucide-react";

export function EmptyState({ label }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <Inbox size={24} className="text-ink-muted mb-2.5" strokeWidth={1.5} />
      <p className="text-xs text-ink-muted">{label}</p>
    </div>
  );
}

export function LoadingState({ label = "Loading..." }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <Loader2 size={20} className="text-agent animate-spin mb-2.5" />
      <p className="text-xs text-ink-muted">{label}</p>
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <AlertTriangle size={22} className="text-danger mb-2.5" strokeWidth={1.5} />
      <p className="text-xs text-ink-secondary mb-3">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-3 py-1.5 rounded-md bg-base-panelAlt border border-base-border text-xs text-ink-secondary hover:text-ink-primary transition-colors"
        >
          Retry
        </button>
      )}
    </div>
  );
}
