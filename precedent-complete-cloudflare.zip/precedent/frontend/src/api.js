const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch {
      // response had no JSON body — fall back to statusText
    }
    throw new Error(detail);
  }
  return res.json();
}

export const api = {
  submitReview: (input_text) =>
    request("/review", { method: "POST", body: JSON.stringify({ input_text }) }),

  submitCorrection: (review_id, human_correction, reason) =>
    request("/correct", {
      method: "POST",
      body: JSON.stringify({ review_id, human_correction, reason }),
    }),

  getHistory: () => request("/history"),

  getStats: () => request("/stats"),

  health: () => request("/health"),
};
