"""
Placeholder domain guidelines for the code_review demo domain.
Swap this out (or add a second file + config switch) if you change DOMAIN.
Each guideline is short and single-topic on purpose — retrieval works
better over atomic chunks than over one big style-guide paragraph.
"""

CODE_REVIEW_GUIDELINES = [
    {"id": "g01", "text": "Never use bare except clauses; always catch specific exception types so failures aren't silently swallowed."},
    {"id": "g02", "text": "No hardcoded secrets, API keys, or credentials in source code — use environment variables or a secrets manager."},
    {"id": "g03", "text": "All SQL queries must use parameterized queries or an ORM; string-concatenated SQL is a SQL injection risk."},
    {"id": "g04", "text": "Public functions and classes need a docstring explaining purpose, parameters, and return value."},
    {"id": "g05", "text": "Remove debug print statements and console.log calls before merging to main."},
    {"id": "g06", "text": "Functions longer than ~50 lines should usually be split into smaller, single-responsibility functions."},
    {"id": "g07", "text": "New business logic requires accompanying unit tests; a PR that only adds code with no tests should be flagged."},
    {"id": "g08", "text": "Error messages shown to end users must not leak stack traces, internal file paths, or raw exception text."},
    {"id": "g09", "text": "Avoid committing large commented-out code blocks; delete dead code instead of leaving it commented."},
    {"id": "g10", "text": "Public API functions should have type hints on parameters and return values."},
    {"id": "g11", "text": "Database migrations must be reversible (include a down/rollback step) unless explicitly justified in the PR description."},
    {"id": "g12", "text": "Naming should be descriptive; avoid single-letter variable names outside of short loop counters."},
    {"id": "g13", "text": "Any change touching authentication or authorization logic requires a second reviewer, not just the bot's approval."},
    {"id": "g14", "text": "Avoid catching Exception broadly around large blocks; scope try/except tightly around the call that can actually fail."},
    {"id": "g15", "text": "New dependencies should be justified in the PR description — avoid adding a library for something the standard library already covers."},
]
