"""
Thin retrieval layer over ChromaDB. Kept separate from llm.py so Phase 3
can add correction retrieval here without touching the LLM call code.
"""
from app.vectorstore import guidelines_collection, corrections_collection
from app.seed_data import CODE_REVIEW_GUIDELINES
from app.config import CORRECTION_SIMILARITY_THRESHOLD


def seed_guidelines_if_empty():
    """Idempotent — safe to call on every startup. Keeps the demo
    zero-manual-steps: fresh clone + run, guidelines are just there."""
    if guidelines_collection.count() > 0:
        return
    guidelines_collection.add(
        ids=[g["id"] for g in CODE_REVIEW_GUIDELINES],
        documents=[g["text"] for g in CODE_REVIEW_GUIDELINES],
    )


def retrieve_guidelines(query_text: str, k: int = 3):
    """Returns a list of {id, text} dicts, most relevant first."""
    count = guidelines_collection.count()
    if count == 0:
        return []
    results = guidelines_collection.query(
        query_texts=[query_text],
        n_results=min(k, count),
    )
    ids = results["ids"][0]
    docs = results["documents"][0]
    return [{"id": i, "text": d} for i, d in zip(ids, docs)]


def retrieve_corrections(query_text: str, k: int = 3):
    """Returns {id, text, metadata, distance, is_strong_match} dicts.

    distance is raw Chroma distance (lower = more similar). is_strong_match
    is the tunable override signal: when True, the LLM prompt is told to
    weight this correction heavily rather than just "consider" it. Tune
    via CORRECTION_SIMILARITY_THRESHOLD in config.py / .env.
    """
    count = corrections_collection.count()
    if count == 0:
        return []
    results = corrections_collection.query(
        query_texts=[query_text],
        n_results=min(k, count),
        include=["documents", "metadatas", "distances"],
    )
    ids = results["ids"][0]
    docs = results["documents"][0]
    metas = results["metadatas"][0]
    dists = results["distances"][0]
    return [
        {
            "id": i,
            "text": d,
            "metadata": m,
            "distance": dist,
            "is_strong_match": dist <= CORRECTION_SIMILARITY_THRESHOLD,
        }
        for i, d, m, dist in zip(ids, docs, metas, dists)
    ]
