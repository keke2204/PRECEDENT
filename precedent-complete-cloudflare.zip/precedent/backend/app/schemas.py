from datetime import datetime
from typing import Optional

from pydantic import BaseModel, field_validator


class ReviewRequest(BaseModel):
    input_text: str

    @field_validator("input_text")
    @classmethod
    def not_blank(cls, v):
        if not v or not v.strip():
            raise ValueError("input_text cannot be blank")
        return v


class ReviewResponse(BaseModel):
    review_id: int
    input_text: str
    agent_output: str
    cited_guideline: Optional[str] = None
    cited_correction: Optional[str] = None


class CorrectionRequest(BaseModel):
    review_id: int
    human_correction: str
    reason: Optional[str] = None

    @field_validator("human_correction")
    @classmethod
    def not_blank(cls, v):
        if not v or not v.strip():
            raise ValueError("human_correction cannot be blank")
        return v


class CorrectionResponse(BaseModel):
    review_id: int
    stored: bool
    embedding_ref: Optional[str] = None


class HistoryItem(BaseModel):
    id: int
    input_text: str
    agent_output: str
    human_correction: Optional[str]
    corrected_flag: bool
    timestamp: datetime
    cited_guideline: Optional[str] = None
    cited_correction: Optional[str] = None

    class Config:
        from_attributes = True


class BatchStat(BaseModel):
    batch_number: int
    total: int
    corrected: int
    correction_rate: float
