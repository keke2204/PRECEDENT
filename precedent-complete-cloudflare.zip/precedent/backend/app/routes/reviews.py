"""
Phase 3: /correct now actually embeds and stores corrections in Chroma,
and /review's retrieval pulls from both collections — corrections that
are a strong similarity match override the default guideline judgment
(see CORRECTION_SIMILARITY_THRESHOLD in config.py). /stats powers the
correction-rate-over-batches chart in Phase 4.
"""
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.review import Review
from app.retrieval import retrieve_guidelines, retrieve_corrections
from app.llm import generate_review
from app.vectorstore import corrections_collection
from app.schemas import (
    ReviewRequest,
    ReviewResponse,
    CorrectionRequest,
    CorrectionResponse,
    HistoryItem,
    BatchStat,
)

router = APIRouter()


@router.post("/review", response_model=ReviewResponse)
def create_review(payload: ReviewRequest, db: Session = Depends(get_db)):
    guideline_chunks = retrieve_guidelines(payload.input_text, k=3)
    correction_chunks = retrieve_corrections(payload.input_text, k=3)

    result = generate_review(payload.input_text, guideline_chunks, correction_chunks)
    verdict = result.get("verdict", "comment")
    reasoning = result.get("reasoning", "")
    agent_output = f"[{verdict.upper()}] {reasoning}"

    cited_guideline_text = None
    cited_id = result.get("cited_guideline_id")
    if cited_id:
        match = next((g for g in guideline_chunks if g["id"] == cited_id), None)
        if match:
            cited_guideline_text = f"{match['id']}: {match['text']}"

    cited_correction_text = None
    strong = [c for c in correction_chunks if c.get("is_strong_match")]
    if strong:
        meta = strong[0].get("metadata", {})
        cited_correction_text = meta.get("correct_output", strong[0]["text"])

    review = Review(
        input_text=payload.input_text,
        agent_output=agent_output,
        corrected_flag=False,
        cited_guideline=cited_guideline_text,
        cited_correction=cited_correction_text,
    )
    db.add(review)
    db.commit()
    db.refresh(review)

    return ReviewResponse(
        review_id=review.id,
        input_text=review.input_text,
        agent_output=review.agent_output,
        cited_guideline=cited_guideline_text,
        cited_correction=cited_correction_text,
    )


@router.post("/correct", response_model=CorrectionResponse)
def submit_correction(payload: CorrectionRequest, db: Session = Depends(get_db)):
    review = db.query(Review).filter(Review.id == payload.review_id).first()
    if review is None:
        raise HTTPException(status_code=404, detail="Review not found")

    # IMPORTANT: embed the input text itself, not the full correction
    # narrative. Retrieval later queries with a bare new input_text, so
    # the stored document needs to be apples-to-apples with that, or
    # similarity scores come out artificially low and the correction
    # never triggers on genuinely similar future inputs. The narrative
    # (wrong output, right output, reason) still lives in metadata and
    # feeds the LLM prompt — it's just not what gets embedded.
    # uuid4, not a timestamp: two corrections on the same review within
    # the same second (automated scripts, a fast double-click, a retried
    # request) previously collided on embedding_id, and Chroma's add()
    # silently keeps the FIRST document on a duplicate id rather than
    # erroring or overwriting -- meaning the vector store would keep
    # citing a stale, already-superseded correction while SQLite showed
    # the real one. Found by actually testing a double-correction.
    embedding_id = f"corr_{review.id}_{uuid.uuid4().hex}"

    # upsert(), not add(), as a second layer of defense: even in some
    # future collision scenario, upsert overwrites rather than silently
    # keeping stale content.
    corrections_collection.upsert(
        ids=[embedding_id],
        documents=[review.input_text],
        metadatas=[
            {
                "review_id": review.id,
                "input_text": review.input_text,
                "wrong_output": review.agent_output,
                "correct_output": payload.human_correction,
                "reason": payload.reason or "",
            }
        ],
    )

    review.human_correction = payload.human_correction
    review.corrected_flag = True
    review.embedding_ref = embedding_id
    db.commit()

    return CorrectionResponse(
        review_id=review.id,
        stored=True,
        embedding_ref=embedding_id,
    )


@router.get("/history", response_model=list[HistoryItem])
def get_history(db: Session = Depends(get_db)):
    return db.query(Review).order_by(Review.timestamp.asc()).all()


@router.get("/stats", response_model=list[BatchStat])
def get_stats(db: Session = Depends(get_db)):
    """Correction rate per batch of 10 reviews, in submission order —
    the number you cite as proof the agent is learning, not anecdote."""
    reviews = db.query(Review).order_by(Review.id.asc()).all()
    batch_size = 10
    batches = []
    for i in range(0, len(reviews), batch_size):
        batch = reviews[i : i + batch_size]
        corrected = sum(1 for r in batch if r.corrected_flag)
        batches.append(
            BatchStat(
                batch_number=(i // batch_size) + 1,
                total=len(batch),
                corrected=corrected,
                correction_rate=round(corrected / len(batch) * 100, 1),
            )
        )
    return batches
