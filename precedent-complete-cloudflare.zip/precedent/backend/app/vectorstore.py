"""
Vector store setup. Two collections, kept deliberately separate rather
than one collection with a "type" metadata filter — Phase 3 needs to
query them with different weighting logic, and separate collections
make that a lot cleaner than post-filtering one big collection.
"""
import chromadb
from chromadb.utils import embedding_functions

from app.config import CHROMA_PERSIST_DIR, EMBEDDING_MODEL

_client = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)

_embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
    model_name=EMBEDDING_MODEL
)

guidelines_collection = _client.get_or_create_collection(
    name="guidelines",
    embedding_function=_embedding_fn,
    metadata={"hnsw:space": "cosine"},
)

corrections_collection = _client.get_or_create_collection(
    name="corrections",
    embedding_function=_embedding_fn,
    metadata={"hnsw:space": "cosine"},
)


def get_client():
    return _client
