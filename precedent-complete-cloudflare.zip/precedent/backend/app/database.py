from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from app.config import SQLITE_PATH

# check_same_thread=False because FastAPI can hit this from multiple
# threads under uvicorn's default worker; SQLite handles it fine for
# a single-writer demo app.
engine = create_engine(
    f"sqlite:///{SQLITE_PATH}",
    connect_args={"check_same_thread": False},
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency — yields a session, always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Create tables if they don't exist. Called once at startup."""
    from app.models import review  # noqa: F401 (registers the model)
    Base.metadata.create_all(bind=engine)
