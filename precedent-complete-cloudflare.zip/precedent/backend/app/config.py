"""
Central config. Everything that varies between your machine and mine
(or between demo mode and real mode) lives here, read from env vars.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# --- LLM ---
MOCK_MODE = os.getenv("MOCK_MODE", "true").lower() == "true"
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_BASE_URL = "https://api.groq.com/openai/v1"
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

# --- Embeddings ---
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")

# --- Storage ---
SQLITE_PATH = os.getenv("SQLITE_PATH", str(BASE_DIR / "precedent.db"))
CHROMA_PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", str(BASE_DIR / "chroma_data"))

# --- Correction retrieval tuning (Phase 3 will actually use this) ---
# Distance is cosine distance (0 = identical direction, 1 = orthogonal,
# 2 = opposite) now that vectorstore.py sets hnsw:space=cosine explicitly.
# 0.35 (~0.65 cosine similarity) is a reasonable starting point for
# "this is basically the same complaint, not just a loosely related one" —
# but TUNE THIS EMPIRICALLY once real embeddings are running: log a few
# known-similar and known-unrelated PR pairs' actual distances and pick
# a threshold that separates them. Don't defend 0.35 in a viva as-is —
# defend the tuning process instead.
CORRECTION_SIMILARITY_THRESHOLD = float(os.getenv("CORRECTION_SIMILARITY_THRESHOLD", "0.35"))

# --- Domain ---
DOMAIN = os.getenv("DOMAIN", "code_review")
