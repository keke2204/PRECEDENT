"""
Wraps the actual generation step. In real mode this hits Groq via the
openai SDK pointed at Groq's base URL (see config.py) — genuinely a
one-line change to point at a different OpenAI-compatible provider later.
In mock mode it fakes the LLM call but still runs on real retrieval
results, so the RAG plumbing is fully exercised even with no API key
or no internet.
"""
import json
from typing import Optional

from app.config import MOCK_MODE, GROQ_API_KEY, GROQ_BASE_URL, GROQ_MODEL, CORRECTION_SIMILARITY_THRESHOLD

_client = None


def _get_client():
    global _client
    if _client is None:
        from openai import OpenAI
        if not GROQ_API_KEY:
            raise RuntimeError(
                "GROQ_API_KEY is not set but MOCK_MODE=false. "
                "Either set MOCK_MODE=true or provide a key in .env."
            )
        _client = OpenAI(api_key=GROQ_API_KEY, base_url=GROQ_BASE_URL)
    return _client


SYSTEM_PROMPT = """You are an experienced senior engineer performing code review.
You are given a numbered set of team guidelines and (optionally) past
corrections a human reviewer made to your previous judgments.

Respond with ONLY valid JSON, no markdown fences, no prose outside the JSON,
with exactly these keys:
{
  "verdict": "approve" | "request_changes" | "comment",
  "reasoning": "<2-4 sentences explaining the verdict>",
  "cited_guideline_id": "<id of the single most relevant guideline, or null>"
}"""


def _build_user_prompt(input_text: str, guideline_chunks: list, correction_chunks: Optional[list] = None) -> str:
    parts = ["Guidelines:"]
    for g in guideline_chunks:
        parts.append(f"[{g['id']}] {g['text']}")

    if correction_chunks:
        strong = [c for c in correction_chunks if c.get("is_strong_match")]
        weak = [c for c in correction_chunks if not c.get("is_strong_match")]

        if strong:
            parts.append(
                "\nA human reviewer previously corrected you on a case very "
                "similar to this one. Treat this as authoritative and let it "
                "override the default guideline-based judgment where they conflict:"
            )
            for c in strong:
                meta = c.get("metadata", {})
                correct_output = meta.get("correct_output", "")
                reason = meta.get("reason", "")
                line = f"- Correct verdict was: {correct_output}"
                if reason:
                    line += f" (reason: {reason})"
                parts.append(line)

        if weak:
            parts.append(
                "\nLoosely related past corrections (consider, don't treat as binding):"
            )
            for c in weak:
                meta = c.get("metadata", {})
                parts.append(f"- {meta.get('correct_output', c['text'])}")

    parts.append(f"\nReview this PR:\n{input_text}")
    return "\n".join(parts)


def _mock_response(input_text: str, guideline_chunks: list, correction_chunks: Optional[list] = None) -> dict:
    """Canned but retrieval-grounded — cites whatever was actually
    retrieved rather than a fixed string, so the demo still shows real
    RAG behavior (different inputs -> different cited guideline)."""
    strong_corrections = [c for c in (correction_chunks or []) if c.get("is_strong_match")]

    if strong_corrections:
        # A close-enough past correction exists — this is the whole point
        # of the demo: same-shaped input, different (corrected) verdict.
        c = strong_corrections[0]
        meta = c.get("metadata", {})
        correct_output = meta.get("correct_output", c["text"])
        return {
            "verdict": "comment",
            "reasoning": (
                f'[MOCK] A human previously corrected a near-identical case '
                f'(distance={c["distance"]:.3f}, threshold={CORRECTION_SIMILARITY_THRESHOLD}). '
                f'Following that correction: {correct_output}'
            ),
            "cited_guideline_id": guideline_chunks[0]["id"] if guideline_chunks else None,
        }

    if not guideline_chunks:
        return {
            "verdict": "comment",
            "reasoning": "[MOCK] No matching guideline was retrieved for this input — flagging for manual review.",
            "cited_guideline_id": None,
        }

    top = guideline_chunks[0]
    reasoning = f'[MOCK] This most closely matches guideline {top["id"]}: "{top["text"]}"'

    if correction_chunks:
        c = correction_chunks[0]
        reasoning += f' A loosely related past correction exists but similarity was below threshold, so treating this as informational only.'

    return {
        "verdict": "request_changes",
        "reasoning": reasoning,
        "cited_guideline_id": top["id"],
    }


def generate_review(input_text: str, guideline_chunks: list, correction_chunks: Optional[list] = None) -> dict:
    if MOCK_MODE:
        return _mock_response(input_text, guideline_chunks, correction_chunks)

    try:
        client = _get_client()
        user_prompt = _build_user_prompt(input_text, guideline_chunks, correction_chunks)

        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.2,
        )
        raw = response.choices[0].message.content

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            # Model didn't return clean JSON — degrade gracefully rather
            # than 500ing the request. Real content still reaches the user.
            return {"verdict": "comment", "reasoning": raw, "cited_guideline_id": None}

    except Exception as exc:
        # Missing key, network failure, rate limit (Groq free tier: 30
        # req/min), timeout — none of these should crash a live demo.
        # Fall back to the same grounded mock path so the request still
        # returns something coherent, with the real error visible in
        # the reasoning so it's not silently hidden from you either.
        fallback = _mock_response(input_text, guideline_chunks, correction_chunks)
        fallback["reasoning"] = f"[GROQ CALL FAILED: {exc}] Falling back to mock judgment. {fallback['reasoning']}"
        return fallback
