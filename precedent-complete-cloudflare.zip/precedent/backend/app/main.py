from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.database import init_db
from app.retrieval import seed_guidelines_if_empty
from app.routes.reviews import router as reviews_router
from app.config import MOCK_MODE, DOMAIN

app = FastAPI(title="Precedent", version="0.1.0")

# Wide open for local dev / Phase 1-3. Harmless to leave permissive even
# once we're single-origin in Phase 5 — no external frontend depends on
# a tighter policy, and it costs nothing for a local/demo deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()
    seed_guidelines_if_empty()


@app.get("/health")
def health():
    return {"status": "ok", "mock_mode": MOCK_MODE, "domain": DOMAIN}


app.include_router(reviews_router)

# Single-origin serving: the built React app (frontend/dist) is served
# by this same FastAPI process, so one Cloudflare Tunnel covers both
# frontend and backend — no CORS, no juggling two public URLs.
# Mounted LAST so it doesn't shadow the API routes above; StaticFiles
# with html=True serves index.html at "/" automatically.
_frontend_dist = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
if _frontend_dist.exists():
    app.mount("/", StaticFiles(directory=str(_frontend_dist), html=True), name="frontend")
