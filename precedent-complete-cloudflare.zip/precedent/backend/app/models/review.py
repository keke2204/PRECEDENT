from datetime import datetime, timezone

from sqlalchemy import Column, Integer, String, Boolean, DateTime

from app.database import Base


class Review(Base):
    """
    One row per item the agent reviewed.

    embedding_ref points at the Chroma document id for this review's
    correction record (only set once/if a correction is logged) —
    lets us go from a SQLite row to its vector-store entry and back.
    """
    __tablename__ = "reviews"

    id = Column(Integer, primary_key=True, index=True)
    input_text = Column(String, nullable=False)
    agent_output = Column(String, nullable=False)
    human_correction = Column(String, nullable=True)
    corrected_flag = Column(Boolean, default=False, nullable=False)
    timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    embedding_ref = Column(String, nullable=True)
    # Added after Phase 4: GET /history was silently losing citation
    # context on every review after a page refresh, since it was only
    # ever returned in the live POST /review response, never stored.
    cited_guideline = Column(String, nullable=True)
    cited_correction = Column(String, nullable=True)
