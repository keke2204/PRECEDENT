"""
30 synthetic PR descriptions for demoing Precedent.

Deliberately structured, not randomly ordered:
  - Batch 1 (items 1-10): 7 DISTINCT issue patterns appear for the first
    time, plus 3 clean PRs. Expect a high correction rate here -- the
    agent hasn't seen any of these patterns corrected yet.
  - Batch 2 (items 11-20): the remaining 4 distinct patterns appear for
    the first time, plus 3 REPEATS of patterns already corrected in
    batch 1 (these should now cite the past correction instead of
    needing a new one), plus 3 more clean PRs.
  - Batch 3 (items 21-30): all REPEATS of patterns already corrected in
    batch 1 or 2, plus 2 clean PRs. Expect near-zero corrections here --
    this is the "visible improvement" batch.

See scripts/run_demo.py for the correction rules and matching logic,
and DEMO_SCRIPT.md for how to narrate this live.
"""

SAMPLE_PRS = [
    # ---- BATCH 1 (1-10): 7 new patterns + 3 clean ----
    "This PR wraps the entire request handler in a bare except: pass to stop 500s from showing in logs.",
    "Added config.py with API_KEY = 'sk-live-abc123' hardcoded for the staging environment.",
    "New search endpoint builds SQL with f-string interpolation of the user's search query directly.",
    "Added a new discount-calculation function with no accompanying unit tests.",
    "Left several print(user.password_hash) statements in the auth module for local debugging.",
    "Added calculate_shipping_cost() with no docstring and no type hints on any parameter.",
    "API error handler returns the raw Python traceback directly in the JSON response body to the client.",
    "Refactored the parser to catch a specific ValueError and TypeError instead of a broad catch-all.",
    "New db.py reads the database password from an environment variable at startup.",
    "Refactored the report query to use SQLAlchemy's parameterized filter instead of manual string building.",

    # ---- BATCH 2 (11-20): 4 new patterns + 3 repeats + 3 clean ----
    "process_order() is now 180 lines long, handles validation, payment, inventory, and email in one function.",
    "Modified the JWT verification logic to skip signature checks in 'debug mode'.",
    "Added the 'leftpad-js' npm package just to left-pad a string in one place.",
    "New Alembic migration drops the legacy_orders column with no downgrade() implemented.",
    "New retry decorator wraps the whole loop in a bare except: pass to avoid crashing the worker.",
    "Committed a .env.production file with a hardcoded Stripe secret key by mistake.",
    "Admin panel's user lookup concatenates the username directly into the SQL WHERE clause.",
    "New public API function get_user_orders(user_id: int) -> list[Order] ships with a full docstring and type hints.",
    "Cleaned up leftover debugging output from the checkout component before merge.",
    "New 500 error page shows a generic 'something went wrong' message with an internal support reference code.",

    # ---- BATCH 3 (21-30): all repeats + 2 clean ----
    "Added refund processing logic but the PR description says 'will add tests in a follow-up'.",
    "New order-processing script has print(f'DEBUG: order details') scattered throughout.",
    "Utility module adds three new helper functions; none documented, no parameter types given.",
    "Login failure response includes the full SQL error message straight from the database driver.",
    "The import_csv() function has grown to 180 lines and handles validation, payment, inventory, and notifications all in one place.",
    "Auth middleware still lets requests skip signature checks in 'debug mode' when a query param is set.",
    "Added the 'leftpad-js' package again in a different service just to pad numbers for display.",
    "Another Alembic migration drops the legacy_orders column with no downgrade() implemented, same as before.",
    "Migration adds a nullable last_login_at column with a proper reversible downgrade step included.",
    "Added a new admin role check before allowing access to the billing dashboard, no existing auth logic touched.",
]
