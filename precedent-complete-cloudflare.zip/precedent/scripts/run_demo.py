"""
Feeds the 30 sample PRs through a LIVE server (run ./scripts/run.sh first)
and simulates a human reviewer: the first time a known issue pattern shows
up, "correct" it; from then on, if the agent already cites that correction
for a similar PR, leave it alone.

This is for REHEARSAL — to confirm the correction-rate trend actually
declines before your live demo, and to auto-populate the dashboard so it
isn't empty when you open it. For the actual live demo in front of
faculty, do the corrections yourself on stage (see DEMO_SCRIPT.md) — it's
more convincing coming from you than a script.

Usage:
    python scripts/run_demo.py [--api http://localhost:8000]
"""
import argparse
import sys
import time
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))
from app.demo_data import SAMPLE_PRS  # noqa: E402

# keyword -> canonical correction the "human" gives the first time that
# pattern shows up uncorrected.
CORRECTION_RULES = [
    (["bare except", "except:", "catches exception broadly", "swallows all exceptions"],
     "REQUEST_CHANGES: never swallow exceptions silently — catch specific exception types and log them.",
     "Bare/broad except clauses hide real failures; this is a hard rule, not a style preference."),
    (["hardcoded", "api_key =", "secret key", "password ="],
     "REQUEST_CHANGES: hardcoded credentials must never be committed, even to staging config.",
     "Hardcoded secrets are a security incident risk regardless of environment."),
    (["f-string interpolation", "concatenates the username", "raw string formatting"],
     "REQUEST_CHANGES: SQL must use parameterized queries — string-built SQL is a SQL injection vector.",
     "This is a security-critical pattern, not a nitpick."),
    (["no accompanying unit tests", "will add tests in a follow-up"],
     "REQUEST_CHANGES: tests must ship with the logic, not in a follow-up PR — follow-ups often don't happen.",
     "Team policy: no exceptions for 'tests later' on business logic."),
    (["print(user.password_hash)", "print(f'debug", "console.log"],
     "REQUEST_CHANGES: remove debug output before merge, especially anything touching credentials.",
     "print(password_hash) is also a security leak into logs, not just noise."),
    (["no docstring and no type hints", "none documented"],
     "COMMENT: please add a docstring and type hints before merge, but not a merge-blocker on its own.",
     "Missing docs matter but shouldn't block on their own unless paired with something riskier."),
    (["raw python traceback", "full sql error message"],
     "REQUEST_CHANGES: never return raw tracebacks or DB error text to the client — leaks internals.",
     "This is an information-disclosure issue."),
    (["180 lines", "handles validation, payment, inventory"],
     "COMMENT: this function is doing too much — suggest splitting, but not necessarily a hard blocker.",
     "Long functions are a maintainability concern, weighted lower than security issues."),
    (["skip signature checks in 'debug mode'"],
     "REQUEST_CHANGES: auth code must never have a bypass path, even behind a debug flag — these leak to prod.",
     "Auth bypass flags are a classic prod-incident cause."),
    (["leftpad-js", "new pr adds 'requests' library"],
     "COMMENT: flag unjustified new dependencies for a second look, don't auto-block.",
     "Dependency bloat is worth noting but rarely worth blocking a PR over."),
    (["drops the legacy_orders column with no downgrade"],
     "REQUEST_CHANGES: migrations must be reversible unless explicitly justified in the PR description.",
     "Irreversible migrations are a production-safety issue."),
]


def find_correction(input_text: str):
    lowered = input_text.lower()
    for keywords, correct_output, reason in CORRECTION_RULES:
        if any(kw in lowered for kw in keywords):
            return correct_output, reason
    return None, None


def run(api_base: str):
    corrected_patterns_seen = set()
    total_corrections = 0

    for i, pr_text in enumerate(SAMPLE_PRS, start=1):
        resp = requests.post(f"{api_base}/review", json={"input_text": pr_text}, timeout=15)
        resp.raise_for_status()
        result = resp.json()

        already_cites_correction = bool(result.get("cited_correction"))
        correct_output, reason = find_correction(pr_text)

        if already_cites_correction:
            print(f"[{i:02d}] ACCEPTED (agent already applied a past correction) — {pr_text[:60]}...")
            continue

        if correct_output and correct_output not in corrected_patterns_seen:
            c = requests.post(
                f"{api_base}/correct",
                json={
                    "review_id": result["review_id"],
                    "human_correction": correct_output,
                    "reason": reason,
                },
                timeout=15,
            )
            c.raise_for_status()
            corrected_patterns_seen.add(correct_output)
            total_corrections += 1
            print(f"[{i:02d}] CORRECTED (new pattern) — {pr_text[:60]}...")
        else:
            print(f"[{i:02d}] ACCEPTED (no rule matched / already have this pattern) — {pr_text[:60]}...")

        time.sleep(0.05)  # be gentle on Groq's free-tier rate limit in real mode

    print(f"\nDone. {total_corrections} corrections logged across {len(SAMPLE_PRS)} reviews.")

    stats = requests.get(f"{api_base}/stats", timeout=15).json()
    print("\nCorrection rate by batch:")
    for b in stats:
        bar = "#" * int(b["correction_rate"] / 5)
        print(f"  batch {b['batch_number']}: {b['correction_rate']:>5.1f}%  {bar}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--api", default="http://localhost:8000")
    args = parser.parse_args()
    run(args.api)
