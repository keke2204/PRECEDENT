#!/usr/bin/env bash
# Exposes the running server (./scripts/run.sh, port 8000) via a free
# Cloudflare Tunnel — no account, no payment, works from any network.
# The server must already be running in another terminal before you run this.
set -e

if ! command -v cloudflared &> /dev/null; then
  echo "cloudflared not found. See DEPLOYMENT.md for install commands for your OS."
  exit 1
fi

echo "==> Starting Cloudflare Tunnel -> http://localhost:8000"
echo "==> Your public URL will appear below (https://<random-name>.trycloudflare.com)"
echo "==> This URL changes every time you restart this command."
cloudflared tunnel --url http://localhost:8000
