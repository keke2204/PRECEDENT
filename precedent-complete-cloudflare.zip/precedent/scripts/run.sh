#!/usr/bin/env bash
# Starts the single-origin server: FastAPI serves both the API and the
# built React app on the same port. Run ./scripts/build.sh first.
set -e

cd "$(dirname "$0")/../backend"

if [ ! -f .env ]; then
  echo "No .env found — copying .env.example (MOCK_MODE=true by default)."
  cp .env.example .env
fi

if [ ! -d ../frontend/dist ]; then
  echo "frontend/dist not found — run ./scripts/build.sh first."
  exit 1
fi

if [ ! -x venv/bin/uvicorn ]; then
  echo "backend/venv not found — run ./scripts/build.sh first."
  exit 1
fi

echo "==> Starting Precedent on http://localhost:8000"
./venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
