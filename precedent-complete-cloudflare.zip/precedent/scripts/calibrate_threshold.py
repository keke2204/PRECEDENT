"""
Run this once you have real embeddings working (i.e. NOT in this sandbox,
where huggingface.co is blocked) to pick a defensible
CORRECTION_SIMILARITY_THRESHOLD instead of guessing.

It embeds a few pairs of PR descriptions -- some that describe the SAME
underlying issue in different words, some that are genuinely unrelated --
and prints the cosine distance for each. Pick a threshold that sits
between your "should match" and "should NOT match" pairs.

Usage:
    cd backend && python ../scripts/calibrate_threshold.py
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from app.config import EMBEDDING_MODEL

# (label, text_a, text_b, should_match) -- should_match is your own
# judgment call about whether these two describe "the same issue".
PAIRS = [
    (
        "same issue, different phrasing",
        "This PR wraps the entire request handler in a bare except: pass to stop 500s from showing in logs.",
        "New retry decorator wraps the whole loop in a bare except: pass to avoid crashing the worker.",
        True,
    ),
    (
        "same issue, very different phrasing",
        "Added config.py with API_KEY = 'sk-live-abc123' hardcoded for the staging environment.",
        "Committed a .env.production file with a hardcoded Stripe secret key by mistake.",
        True,
    ),
    (
        "different issues entirely",
        "This PR wraps the entire request handler in a bare except: pass to stop 500s from showing in logs.",
        "Added a new admin role check before allowing access to the billing dashboard, no existing auth logic touched.",
        False,
    ),
    (
        "different issues, superficially similar length/domain",
        "New search endpoint builds SQL with f-string interpolation of the user's search query directly.",
        "Utility module adds three new helper functions; none documented, no parameter types given.",
        False,
    ),
]


def cosine_distance(vec_a, vec_b):
    a, b = np.array(vec_a), np.array(vec_b)
    similarity = np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    return 1.0 - similarity


def main():
    from chromadb.utils import embedding_functions

    ef = embedding_functions.SentenceTransformerEmbeddingFunction(model_name=EMBEDDING_MODEL)

    print(f"Using embedding model: {EMBEDDING_MODEL}\n")
    print(f"{'label':55s} {'should_match':>13s} {'cosine_distance':>16s}")
    print("-" * 88)

    # Embed every distinct text once (a few pairs deliberately reuse the
    # same text_a to test it against multiple text_b's -- embed each
    # unique string only once rather than re-embedding duplicates).
    all_texts = sorted({t for pair in PAIRS for t in (pair[1], pair[2])})
    embeddings = dict(zip(all_texts, ef(all_texts)))

    for label, a, b, should_match in PAIRS:
        dist = cosine_distance(embeddings[a], embeddings[b])
        print(f"{label:55s} {str(should_match):>13s} {dist:>16.4f}")

    print(
        "\nPick CORRECTION_SIMILARITY_THRESHOLD somewhere between the highest "
        "'should_match=True' distance and the lowest 'should_match=False' "
        "distance above. Put the number + your reasoning in your report."
    )


if __name__ == "__main__":
    main()
