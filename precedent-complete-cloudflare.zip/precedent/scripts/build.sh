#!/usr/bin/env bash
# Builds the frontend and installs backend deps.
# Run this once before ./scripts/run.sh (or after any frontend change).
set -e

cd "$(dirname "$0")/.."

echo "==> Installing frontend deps"
cd frontend
npm install
echo "==> Building frontend (output: frontend/dist)"
npm run build
cd ..

echo "==> Setting up backend virtual environment"
cd backend
if [ ! -d venv ]; then
  python3 -m venv venv
fi
./venv/bin/pip install --upgrade pip -q

echo "==> Installing PyTorch (CPU-only build — sentence-transformers needs it,"
echo "    but this project never touches a GPU, and the default PyPI wheel"
echo "    pulls 2GB+ of unnecessary CUDA libraries on Linux)"
./venv/bin/pip install torch --index-url https://download.pytorch.org/whl/cpu

echo "==> Installing remaining backend deps"
./venv/bin/pip install -r requirements.txt

echo "==> Done. Run ./scripts/run.sh to start the server."
